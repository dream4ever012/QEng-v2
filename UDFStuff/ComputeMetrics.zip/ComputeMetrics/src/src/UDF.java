package src;

public class UDF {
	
	//Dieing a little inside setting it to double to make it ... inefficient. 
	public static double ComputeMetrics(String filePath)
	{
		//how I would write this
		//return new ComputeMetrics(75.0).getFaultProneScore();
		
		ComputeMetrics computeMetrics = new ComputeMetrics(75.0); 
		
		//boolean faultProne = computeMetrics.isFaultProne(filePath);	
		return computeMetrics.getFaultProneScore();
	}
	
	
	public static boolean isFaultProne(String filePath)
	{
		//How I would write it, unnamed object doesn't need to be added to the symbol table, it's created called and then free for the garbage collector because there is no refrence for it.
		//no boolean to be added to the symbol table.
		//return new ComputeMetrics(75.0).isFaultProne(filepath);
		
		ComputeMetrics computeMetrics = new ComputeMetrics(75.0); 

		// Call this line for each individual file.
		//String fileName = "c:\\Cassandra22\\src\\java\\org\\apache\\cassandra\\utils\\SortedBiMultiValMap.java";
		boolean faultProne = computeMetrics.isFaultProne(filePath);
		
		return faultProne;
	}
	
	
	//TODO: setup a version to call another server and get a response.
	public static double ComputeMetricsRemote(String filePath)
	{
		return 0.0;
	}
	
	
	//TODO: setup a version to call another server and get a response.
	public static boolean isFaultProneRemote(String filePath)
	{
		return false;
	}
	
}
