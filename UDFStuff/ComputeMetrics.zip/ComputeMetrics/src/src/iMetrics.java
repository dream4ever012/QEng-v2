package src;

public interface iMetrics {
	public Double nextLine(String line);
	public void resetAllValues();
}
